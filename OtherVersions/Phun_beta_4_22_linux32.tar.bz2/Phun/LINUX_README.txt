Run the program like this: ./phun
