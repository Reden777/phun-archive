This file decribes how you can create your own fonts. 

First of all, you need to create a square 8-bit .raw image file with your 256 characters in a 16x16 grid (row major). 

Optionally you can also create a .dat file containing the widths of each of the 256 characters. This .dat must be in binary format with either 8 or 16 bits (little endian) per character. The unit for the widths is in pixels. So if you have a 1024x1024 .raw image file and want a character to be 32 pixels wide (half of maximum, which is 1024/16=64) you need to have the value 32 in the .dat file at the right place.