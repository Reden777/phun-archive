uniform mat3 TexMatrix;

void main()
{
	gl_TexCoord[0] = gl_MultiTexCoord0;
	gl_TexCoord[1].xyz = TexMatrix * vec3(gl_MultiTexCoord0.xy, 1);
	gl_Position = ftransform();
} 
