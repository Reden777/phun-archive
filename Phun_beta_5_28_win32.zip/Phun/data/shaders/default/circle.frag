///////////////////////////
// Common stuff

uniform vec4   InsideColor;
uniform vec4   BorderColor;
uniform float  BorderWidth;
uniform float  PixelSize;

float Smooth(float ps, float a)
{
	//return smoothstep(-ps, +ps, a);
	//return (a < -ps*0.5) ? 0.0 : (a > +ps*0.5) ? 1.0 : (a+ps*0.5)/ps;
	return clamp(a/ps+0.5, 0.0, 1.0);
}

vec4 CalcColor(float d, vec4 insideColorHere)
{	
	d = -d; // Invert, so that d is the depth into the body
	
	if (d < BorderWidth*0.5) // Outside-fade
		return vec4(BorderColor.rgb, BorderColor.a * Smooth(PixelSize, d));
	else // Inside fade
		return mix(BorderColor, insideColorHere, Smooth(PixelSize, d-BorderWidth));
}

//////////////////////////

uniform float Radius;
uniform float SquareScale;
uniform vec4  CakeSlizeColor;
uniform float CakeSize; // 0 = no cake, 1 = all cake, 0.5=half cake etc

void main()
{
	const float pi = 3.141592653589793;

	vec2 tc = gl_TexCoord[0].st * 2.0 - 1.0;
	float dist = length(tc) * Radius * SquareScale;
	
	float t = atan(tc.y, tc.x); // In [-pi, +pi]
	float cakeSize = CakeSize * pi;
	vec4 insideColorHere = mix(InsideColor, CakeSlizeColor, 1.0-Smooth(PixelSize / dist, abs(t)-cakeSize));
	gl_FragColor = CalcColor(dist - Radius, insideColorHere);
}
