///////////////////////////
// Common stuff

float Smooth(float ps, float a)
{
	//return smoothstep(-ps, +ps, a);
	//return (a < -ps*0.5) ? 0.0 : (a > +ps*0.5) ? 1.0 : (a+ps*0.5)/ps;
	return clamp(a/ps+0.5, 0.0, 1.0);
}

//////////////////////////

varying vec4 Color;

uniform float PixelSize;

void main()
{
	gl_FragColor = Color;
	vec2 tc = gl_TexCoord[0].xy;
	float x = tc.x;
	float width = tc.y;
	
	float ps = PixelSize;
	
	float aa = 1.0;
	
	if (x < ps)
		aa = x/ps;
		
	if (x > width - ps)
		aa = min(aa, (width-x)/ps);
		
	if (width < 2.0*ps) aa *= width/(2.0*ps);
		
	gl_FragColor.a *= aa;
}
