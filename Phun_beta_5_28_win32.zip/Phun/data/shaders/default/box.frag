///////////////////////////
// Common stuff

uniform vec4   InsideColor;
uniform vec4   BorderColor;
uniform float  BorderWidth;
uniform float  PixelSize;

float Smooth(float ps, float a)
{
	//return smoothstep(-ps, +ps, a);
	//return (a < -ps*0.5) ? 0.0 : (a > +ps*0.5) ? 1.0 : (a+ps*0.5)/ps;
	return clamp(a/ps+0.5, 0.0, 1.0);
}

vec4 CalcColor(float d)
{	
	d = -d; // Invert, so that d is the depth into the body
	
	if (d < BorderWidth*0.5) // Outside-fade
		return vec4(BorderColor.rgb, BorderColor.a * Smooth(PixelSize, d));
	else // Inside fade
		return mix(BorderColor, InsideColor, Smooth(PixelSize, d-BorderWidth));
}

//////////////////////////

uniform vec2 HalfSize;

void main()
{
	vec2 tc = gl_TexCoord[0].st;
	vec2 depths = HalfSize - abs(tc);
	float depth = min(depths.x, depths.y);
	gl_FragColor = CalcColor(-depth);
}
