///////////////////////////
// Common stuff

uniform vec4   InsideColor;
uniform vec4   BorderColor;
uniform float  BorderWidth;
uniform bool   TexturedBorder;
uniform float  PixelSize;
uniform sampler2D TexSampler;

float Smooth(float ps, float a)
{
	//return smoothstep(-ps, +ps, a);
	//return (a < -ps*0.5) ? 0.0 : (a > +ps*0.5) ? 1.0 : (a+ps*0.5)/ps;
	return clamp(a/ps+0.5, 0.0, 1.0);
}

vec4 CalcColor(float d)
{
	vec4 texColor = texture2D(TexSampler, gl_TexCoord[1].st);
	
	vec4 insideColor = InsideColor * texColor;
	vec4 borderColor = BorderColor;
	if (TexturedBorder)
		borderColor *= texColor;
		
	d = -d; // Invert, so that d is the depth into the body
	
	if (d < BorderWidth*0.5) // Outside-fade
		return vec4(borderColor.rgb, borderColor.a * Smooth(PixelSize, d));
	else // Inside fade
		return mix(borderColor, insideColor, Smooth(PixelSize, d-BorderWidth));
}

//////////////////////////

uniform float Radius;
uniform float SquareScale;
uniform vec4  CakeSlizeColor;
uniform float CakeSize; // 0 = no cake, 1 = all cake, 0.5=half cake etc

void main()
{
	const float pi = 3.141592653589793;

	vec2 tc = gl_TexCoord[0].st * 2.0 - 1.0;
	float dist = length(tc) * Radius * SquareScale;
		
	gl_FragColor = CalcColor(dist - Radius);
	
	float t = atan(tc.y, tc.x); // In [-pi, +pi]
	float cakeSize = CakeSize * pi;
	gl_FragColor.rgb = mix(gl_FragColor.rgb, CakeSlizeColor.rgb, 1.0-Smooth(PixelSize / dist, abs(t)-cakeSize));
}
