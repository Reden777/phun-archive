///////////////////////////
// Common stuff

uniform vec4   InsideColor;
uniform vec4   BorderColor;
uniform float  BorderWidth;
uniform bool   TexturedBorder;
uniform float  PixelSize;
uniform sampler2D TexSampler;

float Smooth(float ps, float a)
{
	//return smoothstep(-ps, +ps, a);
	//return (a < -ps*0.5) ? 0.0 : (a > +ps*0.5) ? 1.0 : (a+ps*0.5)/ps;
	return clamp(a/ps+0.5, 0.0, 1.0);
}

vec4 CalcColor(float d)
{
	vec4 texColor = texture2D(TexSampler, gl_TexCoord[1].st);
	
	vec4 insideColor = InsideColor * texColor;
	vec4 borderColor = BorderColor;
	if (TexturedBorder)
		borderColor *= texColor;
		
	d = -d; // Invert, so that d is the depth into the body
	
	if (d < BorderWidth*0.5) // Outside-fade
		return vec4(borderColor.rgb, borderColor.a * Smooth(PixelSize, d));
	else // Inside fade
		return mix(borderColor, insideColor, Smooth(PixelSize, d-BorderWidth));
}

//////////////////////////

uniform vec2 HalfSize;

void main()
{
	vec2 tc = gl_TexCoord[0].st;
	vec2 depths = HalfSize - abs(tc);
	float depth = min(depths.x, depths.y);
	gl_FragColor = CalcColor(-depth);
}
