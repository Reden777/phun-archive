uniform sampler2D FieldSampler;
uniform float Cutoff;
uniform vec4 Color;

const float Wiggle = 0.15;

void main()
{
	vec2 tc = gl_TexCoord[0].st;
	vec4 tex = texture2D(FieldSampler, tc);
	
	float meta = tex.a;
	
	float water  = smoothstep(Cutoff-Wiggle, Cutoff+Wiggle, meta);
	gl_FragColor = Color;
	gl_FragColor.a *= water;
	
	float foam = abs(meta-Cutoff) / (Wiggle * 1.0);
	if (foam < 1.0)
		gl_FragColor.rgb = mix(gl_FragColor.rgb, vec3(0.5,0.5,1.0), 1.0-foam);
	
	float select = abs(tex.r-Cutoff) / (Wiggle * 2.0);
	if (select < 1.0)
		gl_FragColor.rgb += vec3(1.0) * (1.0-select);
}
