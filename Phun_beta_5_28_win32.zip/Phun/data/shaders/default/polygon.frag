///////////////////////////
// Common stuff

uniform vec4   InsideColor;
uniform vec4   BorderColor;
uniform float  BorderWidth;
uniform float  PixelSize;

float Smooth(float ps, float a)
{
	//return smoothstep(-ps, +ps, a);
	//return (a < -ps*0.5) ? 0.0 : (a > +ps*0.5) ? 1.0 : (a+ps*0.5)/ps;
	return clamp(a/ps+0.5, 0.0, 1.0);
}

vec4 CalcColor(float d)
{	
	d = -d; // Invert, so that d is the depth into the body
	
	if (d < BorderWidth*0.5) // Outside-fade
		return vec4(BorderColor.rgb, BorderColor.a * Smooth(PixelSize, d));
	else // Inside fade
		return mix(BorderColor, InsideColor, Smooth(PixelSize, d-BorderWidth));
}

//////////////////////////

uniform sampler2D DistSampler;
uniform float DistScale;

void main()
{
	vec2 tc = gl_TexCoord[0].st;
	float d = texture2D(DistSampler, tc).a;
	gl_FragColor = CalcColor((d*2.0 - 1.0) * DistScale);
	//gl_FragColor = vec4(vec3(0.5 + (d-0.5)*1.0),1.0); // Draws the dfistance map
}
