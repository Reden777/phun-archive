uniform sampler2D FieldSampler;
uniform float Cutoff;
uniform vec4 Color;

const float Wiggle = 0.05;

void main()
{
	vec2 tc = gl_TexCoord[0].st;
	vec4 tex = texture2D(FieldSampler, tc);
	float bottom = tex.a;
	float s = smoothstep(Cutoff-Wiggle, Cutoff+Wiggle, bottom);	
	gl_FragColor = Color;
	gl_FragColor.a *= s;
}
