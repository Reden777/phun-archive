Phun, a 2D physics sandbox by Emil Ernerfeldt.
Copyright 2008, Algoryx Simualtion (www.algoryx.se).
Contact:  phungame@gmail.com
Homepage: www.phunland.com

Beta 4.22, 2008-08-12

Phun is free for non-commercial use. You may use it freely for education if credit is given to www.phunland.com.
Use Phun at your own risk! It comes with no warranty, and it can be quite addictive!

For how to use the program, see the help files in Data/Language/ or click the help button inside Phun.
If you lack a translation to your language, go to http://www.phunland.com/wiki/Translations

If you have problems running the program, follow these steps:
- Download the latest graphics drivers for your computer
- Set your monitor bit depth to 32-bits (or set Phun to 16 bit by adding "System.depth = 16;" to config.cfg, see below)
- Disable any secondary monitors

Try Phun again, if no success, try these things:
- Erase the contents of config.cfg (or create an empty config.cfg if none exists, in the same folder as autoexec.cfg).
- Try setting different resolutions on your monitor
- Try setting these config variables (again, at the end of config.cfg) to different things:
	System.fullscreen = true; // or try false
	System.resolution = [1024, 768]; // or your default resolution
	System.vSync = false;


Changelog: (Can also be vieved at http://www.phunland.com/wiki/Phun_changelog)

=== Beta 4.22, 2008-08-12 ===
* Fixed a bug where Phun would crash when cloning after first deleting items (thanks for helping me replicate, tatt61880)
* Added the console command App.GUI.dragUndo. If set to false, drags can't be undone.

=== Beta 4.21, 2008-08-12 ===
* Changed so that the clone tool only selects both the original and the clone iff ctrl is pressed upon release (good idea, tatt61880)
* Fixed a bug where the clone tool would sometimes leave one object out of the clone preview
* Fixed a bug where the scaletool would try to scale an empty group and crash (pointed out by tatt61880)
* Fixed a bug where "toggle" in the hinge controls would be reset on undo (pointed out by vovams).
* Fixed it so that a hinge toggle button that was on gets restored to being on when undoing or loading a scene.
* Added improved logic for determening the mirror axis when binding a key to the mirror command.
* Fixed a bug where the polygon positions after scale/mirror would be very inaccurate for objects far from origo (bug noticed by lucidliquid)
* Added the command "Scene.MoveToOrigo" which moves the entire scene to the center of the world coordinate system. Improves floating point precision.
* Fixed a problem with panning and zooming while using the clone tool (problem pointed out by guyboy)

=== Beta 4.20, 2008-08-08 ===
* Added the ability to assign a key to destroy entities (extrapolated from an idea by Ze Roob)
* Added the ability to assign a key to mirror a group of entities
* Added the ability to turn off collisions between geometries with identical collision settings
* Changed scale tool behavior to scale single circles towards their center
* When cloning objects by holding down CTRL, the simulation is no longer automatically paused, and the cpu work is done when the copy has been dropped. Also, both the original and the clone is selected once the clone is done, which helps when cloning up massive amounts of anything. The clone button in the popup menu is unaffected.
* You can now clone with CTRL when using the drag-tool
* Reduced cpu usage on large scenes
* Fixed a bug where binding certain buttons (.,;=[]{}\) to controll a hinge would create a useless .phn file (thanks for pointing it out, Cyanide Cloud et al)
* Fixed a rare problem with moving pens and attaching them to new geometries
* Fixed a bug where cloning, scaling or moving several objects would sometimes attach joints to the wrong entities
* Fixed a bug where glued geometries (geoms sharing the same body without a fixjoint) would detach when scaled (thanks, tatt61880)
* Fixed a bug where objects once connected with hinges would never collide again, even when the hinges were removed (thanks for pointing it out, are11)
* Fixed a bug where a cloned entity would loose some of its attributes (density, restitution etc) when undoing or saving the scene (pointed out by RicH).
* Fixed a bug where Phun would crash if pressing escape while rotating, moving or dragging an object (it now aborts the operation).
* Fixed a problem where very small polygons would sometimes crash Phun (and also decreased the likelihood of them looking very weird).
* Fixed a problem where two or more water particles would get 'tied' together
* Fixed it so that dragging something is (again) an undoable action
* Fixed a bug where the Scene title would be lost when Undoing (pointed out by tatt61880).
* Fixed a bug where objects fixated together would get incorrect velocities when the fixate was removed (bug found by Rabidmonkey)

=== Beta 4.13, 2008-07-15 ===
* Fixed a problem in 4.12 where the brake-button on hinges in old beta 4 scenes wouldn't work (since I used to misspell them "break"...)
* Fixed a problem with cloning pens		
* Added a menu option to change the target length of a spring (I know this has been requested for quite some time now...)
* Added the ability to click with your middle mosue button to reset the geom directional controller selectors as well as the hinge controller selectors.
* May have solved the horrible "pressing undo clears the scene and won't let me redo" bug. (time will tell)
* Added a auto-brake option to the hinge controller. When this is on, the hinge will brake whenever the forward, back or brake buttons aren't pressed (so the brake-key becomes the neutral-key). Suggested by ostfisk and others
* Added error messages with line numbers on tokenizer errors - should help translators.
* Added translation: Francais
* Fixed a problem with loading old .phn files: when joints were attached to planes they would often get messed up positions
* Fixed so that the camera pans to any tracked objects when loading old .phn files.
* Slightly enhanced scale tool visual aid
* Slightly enhanced rotation- and scale center choice algorithm
* Added undo/redo for common scene settings (water color, gravity etc) - should fix the "I need to re-enter the scene info each time I save" bug
* Fixed a bug where removing a hinge between two objects would automaticly turn on collision for those objects, even if there were still another hinge connecting them.
* Added the ability to bind a combination of several keys with the console command Keys.bind

=== Beta 4.12, 2008-07-09 ===
* Optimized input handling, especially on Linux
* Fixed a problem where water wouldn't show behind a transparent object
* Fixed a bug where circles, boxes and planes couldn't be transparent when there was water in the scene and anti-aliasing and simple water was both off.
* Fixed some issues with the water rendering when anti-aliasing and simple water was both off.
* Added texture prefetching so that phun doesn't freeze up the first time you draw a circle or open a menu
* Added unit to the density slider (kg/m²)
* Fixed a bug where the directional controller on a geometry would apply a force proportional to the frame rate (and much less force than it should)
* Added four translations: Czech, Deutsch, Español and Portugues brasileiro
* Fixed some problems with undoing water
* Fixed some strange behavior regarding loosen and glue
* Added the ability to double-click to open context menus, and to select all the text in a textbox
* Fixed a problem with zero-fade time of pens (thanks, VeeTō)
* Added the ability to pan by holding down both mouse buttons (left and right). This means you can pan anytime, anywhere: in the middle of drawing a polygon you can pan away and then continue drawing, and you can start panning without access to the background.
* Optimized scenes with pens slightly

=== Beta 4.11, 2008-07-02 ===
* Fixed a bug where undo:ing would reset the sky color, gravity etc
* Fixed a bug where scenes would be saved to the phunlet directory
* Fixed a bug where importing a phunlet would change the scene name
* Restored the "clear scene" file menu button

=== Beta 4.1, 2008-07-02 ===
* Included a default config.cfg (so backup your old one if you want it saved)
* Turned shaders/anti-aliasing off by default
* Added some tooltips (explaining that shaders and anti-aliasing is the same thing, and that you can load/import both scenes and phunlets)
* Fixed the cloning of springs
* Fixed some problems with scene loading:
**  Controlled hinges have their motors off by default if loading pre beta-4 scenes
**  Bad geometry is forgiven and ignored, and scene loading continues
**  Things with the same body id no longer needs to be attached with a fixjoínt (although it is recommended)
**  Fixed a bug where fixed geometry would sometimes end up in wrong places (bug have been present for quite a while)
* Less lagg when moving the mouse on slow computers
* Changed back to the old behavior of loading scenes in paused mode
* Fixed box scale/mirror bug
* Fixed so that the circle 'cake' is affected by scale/mirror
* More fixate related bugs fixed (causing problems ranging from crashes to invisible planes)
* Fixed controller input (for hinge motors etc) missing key events
* Fixed a problem where deleting the entities used by a free window (like changing color) would make Phun crash.
* Fixed math.pi not working in Thyme
* Fixed a problem where you could loose the cursor in the console
* Pressing backspace now deletes selected entities (as does pressing delete)
* Using fixedsys font for the profilers again
* Increased the hinge impulse break limit slider maximum from 10 to 100
* Fixed a problem where the zoom slider wouldn't be updated when zooming using the scroll wheel.
* Added "Free drawing" checkbox to the options menu - clicking this will allow you to draw inside and around old objects
* Re-added simulation info to the file menu.
* Added cvar Sim.time (good idea, Zuriki)
* Replaced "Clear scene" with "New scene" in the file menu. Pressing this will also reset all the cvars saved in a scene file (water color etc). You can clear the scene without resetting the cvars by pressing "ctrl+a, delete" and then "erase water" in the file menu.
* Added information about the maximum hinge impulse for selected entities in the information window (usefull for determening a good hinge impulse break limit). (Thanks for the idea, Rabidmonkey)
* Removed the ability to set a distance break limit for hinges (you should only need to use the impulse break limit).
* Added a Glue option under the geometry menu (magicly glues objects to the background)
* Added an auto-glue checkbox to the option menu (automaticly glues all new geometry to the background)
* Fixed the "are you sure you want to overwrite..." dialog to work for scenes as well as phunlets.

=== Beta 4.0, 2008-06-27 ===
* Removed superfluous full program path in the save dialog. 
* Removed dependency on OpenGL 2.0 for shaders (should fix the "NULL-function in Shader::Shader" reported by agsgymboy etc)
* Set shaders to be on by default where available (hope this won't foul things up anymore)
* New highlight system: a white border around selected objects (no more blinking)
* Objects can now be translucent
* Added a pen tool that attaches to a geometry and draws a line tracing its path.
* Vastly improved text input system with mouse selection and a lot more
* Hinge motors can now be bound to any keyboard key or joystick/gamepad button
* Geometries can have forces added to them controlled by either keyboard or joysticks/gamepads
* Hinges can be set to break if stretched or strained too much
* The plane tool now angles the plane in 15° increments if shift is pressed, so it is now simple to create horizontal planes.
* Rotating with shift pressed will now re-align single boxes or planes to 15° increments 
* Added scene meta info: title, author and description
* Added setting (gravity, air friction, camera etc) to scene files
* Upgraded the chain tool to work like the brush tool (ie freehand drawing of chains)
* New box primitive (boxes are no longer box-shaped polygons)
* New scale tool
* Added a mirror command to the popup menu
* Added the cvar Resources.force16BitTextures for those having texture problems (type "Resources.force16BitTextures = true" in console)
* Added tooltips for some menu items, such as the tools.
* Holding down the shortcut key for a tool will now only temporarily select it, while quickly pressing it will select it for real.
* Redone the menus quite a bit. They can now be collapsed, renamed (click their titles) and are automaticly saved in the scene and config files.
* You can now have the canera follow a group of objects instead of just one
* You can now move the camera relative to the object (or group of objects) you are following.
* Extended the number of collision groups to five (used to be three).
* Added Phunlets (save a phunlet by right-clicking a group of objects, import a phunlet by right-clicking the background).
* Added the ability to copy- and paste phunlets/objects/thyme-code in Phun (ie: select something, press ctrl-c, and then ctrl-v it where you want a copy or want the code)
* Changed fixate behavior to always fixate the top two geometries, even if they're already connected (same for hinges and springs)
* Phun now starts the simulation whenever a new scene is loaded (though you can immediatly undo this)
* Added ability to change water and sky color in the right click menu.
* Removed some rather arbitrary limits on position, speed and angular velocity
* Fixates and hinges now have a small plus (+) added to them when attached to the background (thanks for the suggestion, Melchior)
* Fixed GUI mouse input opacity (you can no longer click through a GUI window)
* Fixed a few fixate-related bugs
* Fixed a bug where water particles would sometimes collide with a polygon bounding box.
* Various fixes and tweaks

=== Beta 3.5, 2008-03-27 ===
* Ctrl-G now groups objects together, and Ctrl-U ungroups them
* When clicking an object in a group, the entire group is now selected (unless ALT is pressed)
* Fixed a major circle-circle collision bug
* Fixed so that gui windows now get on top when dragged
* Fixed so that more scenes can be displayed under File->Load Scene as well as subdirs to Phun/Scenes
* Optimized the GUI rendering slightly
* Optimized entity rendering by 'frustum' culling
* Added separate option controlling an objects collision with water; making things watertight should now be easy (thanks for suggestion, Chad Autry)
* Added (three) collision groups; objects in one group will only collide with other objects in the same group
* Added an options for showing some simple statistics for selected objects (mass, area, velocity, ...)
* F8 now shows the collision points and their counter force and direction (used to be the collision normal)
* Added the ability to turn on and off the drawing of object borders from the options menu (even in the no-shader path)
* Added translations (accessible under the file menu). Phun now supports (in Latin1):
	Català (Catalan), Deutsch (German), English, Espanol (Spanish), Francais (French), Italiano (Italian), Magyar (Hungarian), Nederlands (Dutch), Polski (Polish), Portugues (Portuguese), Romanian, Suomi (Finnish) and Svenska (Swedish).

=== Beta 3.12, 2008-02-21 ===
* Beta 3.12 removed the dependency on multi texturing support.

=== Beta 3.11, 2008-02-21 ===
* Beta 3.11 fixed a bug Stric pointed out to me

=== Beta 3.1, 2008-02-21 ===
* Removed the dependency on vcredist by compiling with mingw instead (thanks to Zao for the help)
* The linux version now figures out it's path.
* Moving objects moves them to the front of the screen again.
* Moving a geometry does no longer move all objects fixated to it
* You can now set a geometry not to collide with anything else by a checkbox in popup->geom.
* Added two console commands: System.minFPS and System.maxFPS. The simulation will be slowed down to match an FPS of System.minFPS; and the program will sleep so it won't go past System.maxFPS.
* Added the ability to click on a slider value and enter a new one.
* Fixed a bug where the text cursor would be drawn in the wrong place.
* Fixed so air buoyancy and friction adds to the rotation of an object (the heaviest part of an object will tend to fall first etc)
* Set Resources.shaders to false per default. Turn on shaders in the options menu.
* Added an option to turn off the clouds.

=== Beta 3.0, 2008-02-20 ===
* Added the ability to choose object color
* Added the ability to follow objects (right-click them to do so, and right-click background to stop).
* Optimized any scene containing water (more speed improvements to come though).
* Added a file command for removing all water from a scene
* Holding down shift while rotating now rotates in increments of 15°
* Prevented popups from coming to close to the bottom right corner of the screen.
* Set vsync off by default for better performance. Turn on again with System.vSync = true;
* Removed a couple of usages of OpenGL before I had a GL context (may have caused some start-up crashes).
* Fixed a bug where deleting things while moving them would cause the program to crash.
* Added circle LOD; if a circle is less than 10 pixels wide, it will be drawn in a simpler and faster way.
* No longer create the last hinge of a chain connected to the same body (like the world).
* Fixed a bug where you couldn't undo a clone
* Several minor fixes and tweaks.
* Added a Phun program icon by Marty
* Renamed scene files from .cfg to .phn (your old files will be renamed automaticly at startup, and there is full backwards-compability by just renaming).
* Fixed so you know can tell Windows explorer so associate .phn files to Phun (you could before too, but now it works)
* Added an option for simple water rendering (good for FPS and for those having trouble with the other water render paths)
* Holding down ALT while clicking a chain let's you select individual joints.

=== Beta 2.51, 2008-02-17 ===
* Renamed App.shaders to Resources.shaders (just to confuse you), and made it actually work this time.
* Water droplets lie flat on surfaces (looks better)

=== Beta 2.5, 2008-02-16 ===
* Added a non-shader render path (turn on by putting "App.shaders=false;" in autoexec.cfg).
* Added the ability to control hinge motors with the arrow keys.
* Upgraded the tools so that you can draw with the hinge-, drag- and fixate-tools.
* Upgraded the brush tool to drawing straight lines when SHIFT is pressed (thanks to the people who suggested this feature)
* Added an option for drawing objects inside other objects
* Added an option for hiding hinges and fixates when the simulation is running (thanks for the tip, Jooh4n).
* Added autosave of config file.
* Fixed a bug where moving hinged objects may break the hinge
* Fixed a bug where 'Zoom to scene' wouldn't work
* Added detachable submenus to the popup-menu.
* Did some small rendering optimizations
* Added air buoyancy (lighter-than-air flight possible for light-weight objects)
* Renamed CRASH.cfg and LAST.cfg to _AUTOSAVE.cfg and _ONEXITSAVE.cfg

=== Beta 2.3, 2008-02-13 ===
* Fixed a bug where motor hinges would add velocity to the objects attached to it
* Fixed a bug where you could click right through a GUI window

=== Beta 2.2, 2008-02-12 ===
* Redesigned the UI, with new File and Options menus.
* Dissalowed left-click-menus by default. Turn back on in the new options menu
* Slightly better box-box collision detection
* Fixed a bug where the length of springs would be forgotten when moved
* Lowered the default spring strength to make it act a bit more springy by default
* Lowered the default water droplet size
* Fixed a problem where button-clicks would go undetected at low frame-rates
* You can now change the scale of the UI with the console command GUI.Scale
* Optimized the GUI rendering slightly

=== Beta 2.0, 2008-02-07 ===
* Made it easier to rotate planes.
* Added groups. You can now assign objects to group (0-9 on the keyboard) using ctrl-#, and select them by pressing that number.
* Added friction to water, so water droplets no longer slide frictionless over a surface
* Water no longer bounces on objects
* The water is now more stable
* Optimized water-world collision.
* Changed the object look slightly (removed polygon borders)
* Optimized polygon drawing for older hardware (no more floating point textures)
* Fixed a problem where Fixate-crosses would dissapear when they were being moved
* Fixed a bug where a hinge motor would have trouble rotating with a spring attached
* Fixed three seperate instances of the NULL SharedPtr crash, involving geometry-fixating (often occuring during Undo:ing), water and bad objects. Hopefully this will fix all crashes (dream on, Emil...)
* Fixed a major memory leak. Things should run a lot smoother and use less memory from now on.
* Added a window title

=== Beta 1.7, 2008-01-30 ===
* A swedish translation accessible by a clicking the Swedish flag on the left
* Prettier background (clear blue sky with clouds floating)
* Max and minimum zoom level
* Zoom slider
* Help window
* About window
* Redesigned UI
* Single water droplets now evaporates after a while
* New keyboard shortcuts
* A lot of bugfixes
* Bundled TODO.txt and BUGS.txt for all to see
* More things I have forgotten about

=== Beta 1.6, 2008-01-24 ===
* Added Linux binary
* Fixed a bug regaring drawing squares (hold down shift while usign the box tool)
* Removed the guitar background


=== Beta 1.5, 2008-01-23 ===
* Ability to clone objects (drag while holding control, or click selection and choose "clone")
* Objects now have color
* Added hinge motors
* More stable drag tool
* Varius speed optimizations
* Improved UI
* Animated background


=== Beta 1.2, 2007-12-18 ===
* Fixed a bug where adding a fixjoint at the wrong place would crash the program
* Added arrows for the undo/redo buttons making the measier to spot
* Added a (stable) linux binary


=== Beta 1.1, 2007-12-18 ===
* Fixed a bug in the physics solver
* Fixed a bug causing the program to crash when adding zero sized objects
* Rearanged the menu bar and added icons for the panner and zoomer
* Optimized the rendering slightly


=== Beta 1.0, 2007-12-17 ===
* A completely new physics solver!
* A new Chain tool for placing out a string of circles connected with hinges
* The ability to tweak object restitution and friction
* A lot of fixes and tweaks


=== Alpha 4.5, 2007-12-13 ===
* Added support for simpler shaders
* Added sliders for adjusting simulation speed, object density and spring settings
* Added stripes on circles so their rotation can be observed
* Fixed a lot of bugs with the tools
* Fixed crash at exit (at least on Windows)


=== Alpha 4.1, 2007-11-30 ===
* Fixed rendering to work on older hardware


=== Alpha 4, 2007-11-28 ===

Changed:
* Added three tools: Box, FixJoint and Drag
* Added undo/redo
* Added ability to save and load scenes to file
* Visual upgrades
* Friction (Sim.friction)
* Added cvars antiAlias, fullscreen, resizable, resolution and vSync under System. Modify these in the config, or in the console at runtime (follow with a call to System.recreateWindow to apply).


=== Alpha 3, 2007-11-08 ===

Added:
* Fix joints
* Rotational joints
* Water
* Popup-menus for bodies (only two options: erase and liquify)
* Unified rendering for polygons, circles and planes

Fixed:
* Collision detection bugs
* Lots more


=== Alpha 2, 2007-10-31 ===

Features:
* Polygons, circles, planes and springs
* A very simple physics engine (temporary)
* A GUI for choosing different tools (brush, plane, circle and spring)
* A console and the Thyme scripting language (my own)
* Bugs!

Known issues:
* Crashes at exit
* The simulation checkbox not showing the simulation status
